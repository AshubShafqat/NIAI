"""
Task 51 - Implement Linear Regression (scikit-learn)

Follows the StackAbuse tutorial "Linear Regression in Python with Scikit-Learn":
  1) Simple linear regression  (one feature)
  2) Multiple linear regression (several features)
The tutorial uses a downloaded CSV; to run anywhere (no internet / files needed)
this script generates a petrol-consumption style dataset and also uses the
diabetes dataset that ships with scikit-learn. Swap in your own CSV with:
    df = pd.read_csv("petrol_consumption.csv")
"""
import matplotlib
matplotlib.use("Agg")                      # save plots instead of opening windows
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.datasets import load_diabetes
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------------------
# PART 1: SIMPLE LINEAR REGRESSION  (y = m*x + c)
# ---------------------------------------------------------------------------
rng = np.random.default_rng(42)
hours = rng.uniform(1, 10, 100)                          # hours studied
scores = 8.5 * hours + 12 + rng.normal(0, 5, 100)        # marks obtained
df = pd.DataFrame({"Hours": hours, "Scores": scores})
print("Dataset preview:\n", df.head(), "\n")
print(df.describe(), "\n")

X = df[["Hours"]].values          # features must be 2-D
y = df["Scores"].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

model = LinearRegression()
model.fit(X_train, y_train)
print("Intercept:", round(model.intercept_, 3))
print("Slope    :", round(model.coef_[0], 3))

y_pred = model.predict(X_test)
comparison = pd.DataFrame({"Actual": y_test, "Predicted": y_pred}).round(2)
print("\nActual vs Predicted:\n", comparison.head(), "\n")

print("Mean Absolute Error :", round(metrics.mean_absolute_error(y_test, y_pred), 3))
print("Mean Squared Error  :", round(metrics.mean_squared_error(y_test, y_pred), 3))
print("Root Mean Sq. Error :", round(np.sqrt(metrics.mean_squared_error(y_test, y_pred)), 3))
print("R2 score            :", round(metrics.r2_score(y_test, y_pred), 3))
print("Prediction for 7.5 hours:", round(model.predict([[7.5]])[0], 2))

plt.scatter(X_test, y_test, color="gray", label="Actual")
plt.plot(X_test, y_pred, color="red", linewidth=2, label="Regression line")
plt.xlabel("Hours"); plt.ylabel("Scores"); plt.title("Simple Linear Regression")
plt.legend(); plt.tight_layout()
plt.savefig("simple_linear_regression.png", dpi=120)
plt.close()

# ---------------------------------------------------------------------------
# PART 2: MULTIPLE LINEAR REGRESSION (several features)
# ---------------------------------------------------------------------------
print("\n" + "=" * 60 + "\nMULTIPLE LINEAR REGRESSION (diabetes dataset)\n" + "=" * 60)
data = load_diabetes(as_frame=True)
X = data.data
y = data.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
regressor = LinearRegression()
regressor.fit(X_train, y_train)

coeff_df = pd.DataFrame(regressor.coef_, X.columns, columns=["Coefficient"]).round(2)
print("Coefficients:\n", coeff_df, "\n")

y_pred = regressor.predict(X_test)
print(pd.DataFrame({"Actual": y_test.values, "Predicted": y_pred}).round(1).head(), "\n")
print("Mean Absolute Error :", round(metrics.mean_absolute_error(y_test, y_pred), 3))
print("Mean Squared Error  :", round(metrics.mean_squared_error(y_test, y_pred), 3))
print("Root Mean Sq. Error :", round(np.sqrt(metrics.mean_squared_error(y_test, y_pred)), 3))
print("R2 score            :", round(metrics.r2_score(y_test, y_pred), 3))

plt.scatter(y_test, y_pred, alpha=0.7)
plt.plot([y.min(), y.max()], [y.min(), y.max()], "r--")
plt.xlabel("Actual"); plt.ylabel("Predicted"); plt.title("Multiple Linear Regression")
plt.tight_layout()
plt.savefig("multiple_linear_regression.png", dpi=120)
print("\nSaved: simple_linear_regression.png, multiple_linear_regression.png")
