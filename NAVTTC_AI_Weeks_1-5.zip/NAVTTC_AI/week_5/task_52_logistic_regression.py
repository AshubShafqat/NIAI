"""
Task 52 - Perform Logistic Regression

Follows the tutorials on logistic regression with sklearn (MNIST handwriting
recognition) and DataCamp's "Understanding Logistic Regression in Python":
  1) Binary classification  (breast cancer dataset)
  2) Multiclass classification (handwritten digits 0-9, a small MNIST-style set)
Datasets ship with scikit-learn, so no download is required.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.datasets import load_breast_cancer, load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ---------------------------------------------------------------------------
# PART 1: BINARY LOGISTIC REGRESSION
# ---------------------------------------------------------------------------
print("=" * 60 + "\nBINARY CLASSIFICATION (breast cancer: malignant vs benign)\n" + "=" * 60)
cancer = load_breast_cancer()
X, y = cancer.data, cancer.target
print("Samples:", X.shape[0], "| Features:", X.shape[1], "| Classes:", list(cancer.target_names))

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

logreg = LogisticRegression(max_iter=1000)
logreg.fit(X_train, y_train)
y_pred = logreg.predict(X_test)

print("\nAccuracy :", round(metrics.accuracy_score(y_test, y_pred), 4))
print("Precision:", round(metrics.precision_score(y_test, y_pred), 4))
print("Recall   :", round(metrics.recall_score(y_test, y_pred), 4))
print("F1 score :", round(metrics.f1_score(y_test, y_pred), 4))
print("\nConfusion matrix:\n", metrics.confusion_matrix(y_test, y_pred))
print("\nClassification report:\n", metrics.classification_report(y_test, y_pred,
                                                                  target_names=cancer.target_names))
print("Probabilities of first 3 test samples:\n", logreg.predict_proba(X_test[:3]).round(3))

# ROC curve
probs = logreg.predict_proba(X_test)[:, 1]
fpr, tpr, _ = metrics.roc_curve(y_test, probs)
auc = metrics.roc_auc_score(y_test, probs)
plt.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
plt.plot([0, 1], [0, 1], "k--")
plt.xlabel("False positive rate"); plt.ylabel("True positive rate")
plt.title("ROC curve - binary logistic regression"); plt.legend(); plt.tight_layout()
plt.savefig("roc_curve_binary.png", dpi=120)
plt.close()

# ---------------------------------------------------------------------------
# PART 2: MULTICLASS LOGISTIC REGRESSION (digits 0-9)
# ---------------------------------------------------------------------------
print("\n" + "=" * 60 + "\nMULTICLASS CLASSIFICATION (handwritten digits 0-9)\n" + "=" * 60)
digits = load_digits()
print("Image data shape:", digits.images.shape, "| Label data shape:", digits.target.shape)

# Display some sample images
fig, axes = plt.subplots(1, 5, figsize=(10, 2.5))
for ax, image, label in zip(axes, digits.images[:5], digits.target[:5]):
    ax.imshow(image, cmap=plt.cm.gray_r)
    ax.set_title(f"Training: {label}")
    ax.axis("off")
plt.tight_layout()
plt.savefig("digits_samples.png", dpi=120)
plt.close()

X_train, X_test, y_train, y_test = train_test_split(
    digits.data, digits.target, test_size=0.25, random_state=0)

clf = LogisticRegression(max_iter=5000)      # multinomial (softmax) for >2 classes
clf.fit(X_train, y_train)
predictions = clf.predict(X_test)

score = clf.score(X_test, y_test)
print("Accuracy:", round(score, 4))
print("\nClassification report:\n", metrics.classification_report(y_test, predictions))

cm = metrics.confusion_matrix(y_test, predictions)
print("Confusion matrix:\n", cm)

plt.figure(figsize=(7, 6))
plt.imshow(cm, cmap="Blues")
plt.title(f"Confusion matrix (accuracy = {score:.3f})")
plt.xlabel("Predicted label"); plt.ylabel("Actual label")
plt.colorbar()
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, cm[i, j], ha="center", va="center",
                 color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=8)
plt.tight_layout()
plt.savefig("confusion_matrix_digits.png", dpi=120)

# Show a few misclassified images
wrong = np.where(predictions != y_test)[0][:5]
print("\nMisclassified examples (actual -> predicted):",
      [(int(y_test[i]), int(predictions[i])) for i in wrong])
print("\nSaved: roc_curve_binary.png, digits_samples.png, confusion_matrix_digits.png")
