"""
Task 42 - Pandas installation / getting started

Install with:   pip install pandas          (or)   conda install pandas
This script verifies the installation and runs the first Pandas example.
"""
import subprocess
import sys

try:
    import pandas as pd
except ImportError:
    print("Pandas not found - installing it with pip ...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pandas"])
    import pandas as pd

# Check version
print("Pandas version:", pd.__version__)

# Import with the usual alias 'pd' and create a first object
mydataset = {"cars": ["BMW", "Volvo", "Ford"], "passings": [3, 7, 2]}
myvar = pd.DataFrame(mydataset)
print(myvar)

# Pandas depends on NumPy, check it too
import numpy as np
print("NumPy version :", np.__version__)
print("Python version:", sys.version.split()[0])
