"""Task 46 - Pandas: analyzing data"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(1)
df = pd.DataFrame({
    "Duration": rng.choice([30, 45, 60, 90], size=40),
    "Pulse": rng.integers(95, 130, size=40),
    "Maxpulse": rng.integers(120, 180, size=40),
    "Calories": rng.uniform(150, 500, size=40).round(1),
})

# Viewing the data
print("head():\n", df.head())          # first 5 rows
print("\nhead(10) shape:", df.head(10).shape)
print("\ntail():\n", df.tail())        # last 5 rows

# Info about the data
print()
df.info()

# Statistical summary
print("\ndescribe():\n", df.describe())

# More analysis
print("\nShape        :", df.shape)
print("Columns      :", list(df.columns))
print("Missing      :\n", df.isnull().sum())
print("Duration counts:\n", df["Duration"].value_counts())
print("Mean calories by duration:\n", df.groupby("Duration")["Calories"].mean().round(2))
print("Sorted by calories (top 3):\n", df.sort_values("Calories", ascending=False).head(3))
print("Unique durations:", df["Duration"].unique())
