"""Task 47 - Pandas: data cleaning techniques"""
import numpy as np
import pandas as pd

# A deliberately "dirty" dataset
df = pd.DataFrame({
    "Duration": [60, 60, 45, np.nan, 45, 60, 450, 30, 30],
    "Date": ["2020/12/01", "2020/12/02", "2020/12/03", "2020/12/04", "20201226",
             "2020/12/06", "2020/12/07", "2020/12/08", "2020/12/08"],
    "Pulse": [110, 117, 103, 109, 117, 102, 110, 104, 104],
    "Calories": [409.1, 479.0, 340.0, 282.4, np.nan, 300.5, 374.0, 253.3, 253.3],
})
print("Original data:\n", df)

# 1. EMPTY CELLS
print("\nNull counts:\n", df.isnull().sum())
print("\ndropna():\n", df.dropna())                       # remove rows with empty cells
df2 = df.copy()
df2["Calories"] = df2["Calories"].fillna(130)               # replace with a value
df2["Duration"] = df2["Duration"].fillna(df2["Duration"].mean())   # mean
print("\nAfter fillna:\n", df2)
print("Median:", df["Calories"].median(), "| Mode:", df["Calories"].mode()[0])

# 2. WRONG FORMAT
df2["Date"] = pd.to_datetime(df2["Date"], format="mixed")
print("\nDates converted:\n", df2["Date"])

# 3. WRONG DATA (replace or remove outliers)
df2.loc[df2["Duration"] > 120, "Duration"] = 120            # replace
print("\nMax duration after fix:", df2["Duration"].max())
# or drop rows:  df2.drop(df2[df2["Duration"] > 120].index, inplace=True)

# 4. DUPLICATES
print("\nDuplicated rows:\n", df2.duplicated())
df2 = df2.drop_duplicates()
print("\nAfter drop_duplicates():\n", df2)

# 5. Reset index and rename columns
df2 = df2.reset_index(drop=True).rename(columns={"Pulse": "HeartRate"})
print("\nFinal clean data:\n", df2)
