"""Task 43 - Pandas Series"""
import pandas as pd

# A Series is a one-dimensional labelled array
a = [1, 7, 2]
myvar = pd.Series(a)
print(myvar)

# Labels (index) - default labels are 0, 1, 2 ...
print("\nFirst value:", myvar[0])

# Create your own labels
myvar = pd.Series(a, index=["x", "y", "z"])
print("\n", myvar)
print("Value at label 'y':", myvar["y"])

# Key / value objects (dictionary) as a Series
calories = {"day1": 420, "day2": 380, "day3": 390}
myvar = pd.Series(calories)
print("\n", myvar)

# Only some items of the dictionary
myvar = pd.Series(calories, index=["day1", "day2"])
print("\n", myvar)

# Useful operations
s = pd.Series([10, 20, 30, 40])
print("\nsum/mean/max:", s.sum(), s.mean(), s.max())
print("s * 2:", list(s * 2))
print("s > 15:", list(s > 15))
print("Named series:\n", pd.Series([1, 2], name="numbers"))
