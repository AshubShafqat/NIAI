"""Task 41 - Pandas basics"""
import pandas as pd

# Pandas is used to analyze data: it can clean, explore, manipulate and summarize it.
print("Pandas version:", pd.__version__)

mydataset = {
    "cars": ["BMW", "Volvo", "Ford"],
    "passings": [3, 7, 2],
}
myvar = pd.DataFrame(mydataset)
print(myvar)

# Quick look at structure
print("\nShape  :", myvar.shape)
print("Columns:", list(myvar.columns))
print("Dtypes :\n", myvar.dtypes)

# Basic selection
print("\nCars column:\n", myvar["cars"])
print("Cars with passings > 2:\n", myvar[myvar["passings"] > 2])

# Basic statistics
print("\n", myvar.describe())
