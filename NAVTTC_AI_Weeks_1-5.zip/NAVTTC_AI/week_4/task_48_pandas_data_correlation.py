"""Task 48 - Pandas: data correlations"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(0)
duration = rng.choice([30, 45, 60, 75, 90], size=60)
df = pd.DataFrame({
    "Duration": duration,
    "Pulse": (90 + duration * 0.3 + rng.normal(0, 3, 60)).round(0),
    "Maxpulse": (120 + duration * 0.25 + rng.normal(0, 6, 60)).round(0),
    "Calories": (duration * 5.2 + rng.normal(0, 25, 60)).round(1),
})

# corr() shows the relationship between every pair of numeric columns
print(df.corr())

# Reading the result
#   1.0   -> perfect positive correlation
#   0.0   -> no relationship
#  -1.0   -> perfect negative correlation
#  >0.6 (or <-0.6) is usually considered a good correlation
print("\nCorrelation Duration vs Calories:", round(df["Duration"].corr(df["Calories"]), 3))
print("Correlation Duration vs Pulse   :", round(df["Duration"].corr(df["Pulse"]), 3))

# Strongest correlations with Calories
print("\nCorrelation with Calories:\n", df.corr()["Calories"].sort_values(ascending=False))

# Spearman rank correlation
print("\nSpearman:\n", df.corr(method="spearman").round(3))

# Heatmap (saved to a PNG)
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns
    sns.heatmap(df.corr(), annot=True, cmap="coolwarm")
    plt.title("Correlation heatmap")
    plt.tight_layout()
    plt.savefig("correlation_heatmap.png", dpi=120)
    print("\nSaved correlation_heatmap.png")
except ImportError:
    print("matplotlib/seaborn not installed - heatmap skipped")
