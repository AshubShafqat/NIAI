"""Task 45 - Pandas: reading CSV files"""
from pathlib import Path

import pandas as pd

# Create a sample data.csv next to this script so the program is self-contained
csv_path = Path(__file__).parent / "data.csv"
sample = pd.DataFrame({
    "Duration": [60, 60, 60, 45, 45, 60, 60, 450, 30, 60],
    "Pulse": [110, 117, 103, 109, 117, 102, 110, 104, 109, 98],
    "Maxpulse": [130, 145, 135, 175, 148, 127, 136, 134, 133, 124],
    "Calories": [409.1, 479.0, 340.0, 282.4, 406.0, 300.5, 374.0, 253.3, 195.1, 269.0],
})
sample.to_csv(csv_path, index=False)

# Read the CSV
df = pd.read_csv(csv_path)
print(df.to_string())            # to_string() prints the entire DataFrame

# By default only the first 5 and last 5 rows are shown
print("\n", df)

# max_rows setting
print("\nDefault max_rows:", pd.options.display.max_rows)
pd.options.display.max_rows = 9999

# head / tail / info
print("\nhead(3):\n", df.head(3))
print("\ntail(3):\n", df.tail(3))
df.info()

# Writing a CSV back
df.to_csv(Path(__file__).parent / "data_copy.csv", index=False)
print("\nSaved data_copy.csv")
