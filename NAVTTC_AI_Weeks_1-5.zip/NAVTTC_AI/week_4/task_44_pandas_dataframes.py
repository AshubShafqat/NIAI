"""Task 44 - Pandas DataFrames"""
import pandas as pd

# A DataFrame is a 2-dimensional table (rows and columns)
data = {
    "calories": [420, 380, 390],
    "duration": [50, 40, 45],
}
df = pd.DataFrame(data)
print(df)

# Locate a row with .loc
print("\nRow 0:\n", df.loc[0])
print("\nRows 0 and 1:\n", df.loc[[0, 1]])

# Named indexes
df = pd.DataFrame(data, index=["day1", "day2", "day3"])
print("\n", df)
print("\nLocate named index:\n", df.loc["day2"])

# Column operations
df["ratio"] = df["calories"] / df["duration"]
print("\nWith new column:\n", df)
df = df.drop(columns=["ratio"])

# iloc (integer position), selecting columns
print("\niloc[0:2, 0]:\n", df.iloc[0:2, 0])
print("\nOnly 'calories':\n", df["calories"])

# Adding a row and describing
df.loc["day4"] = [500, 60]
print("\n", df)
print("\nshape:", df.shape, "| columns:", list(df.columns))
