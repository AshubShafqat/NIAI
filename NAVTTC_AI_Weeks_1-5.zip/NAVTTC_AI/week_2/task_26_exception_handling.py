"""Task 26 - Exercise on Exception Handling in Python"""

# 1. try / except
try:
    print(10 / 0)
except ZeroDivisionError:
    print("Error: cannot divide by zero")

# 2. Multiple except blocks
for value in ["10", "abc", None]:
    try:
        print("Converted:", int(value))
    except ValueError:
        print(f"ValueError: '{value}' is not a valid integer")
    except TypeError:
        print("TypeError: wrong type supplied")

# 3. try / except / else / finally
def divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError as err:
        print("Caught:", err)
    else:
        print("Result:", result)       # runs only when no exception
    finally:
        print("finally block always runs")

divide(10, 2)
divide(10, 0)

# 4. Catch several exceptions in one line + generic Exception
try:
    numbers = [1, 2, 3]
    print(numbers[5])
except (IndexError, KeyError) as err:
    print("Lookup error:", err)

try:
    {}["missing"]
except Exception as err:
    print("Generic handler:", type(err).__name__, "-", err)

# 5. Raising exceptions
def check_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative")
    return age

try:
    check_age(-5)
except ValueError as err:
    print("Raised:", err)

# 6. File handling with exceptions
try:
    with open("file_that_does_not_exist.txt") as fh:
        fh.read()
except FileNotFoundError as err:
    print("File error:", err)

# 7. assert
try:
    assert 2 + 2 == 5, "Math is broken"
except AssertionError as err:
    print("AssertionError:", err)

# 8. Re-raise and exception chaining
try:
    try:
        int("x")
    except ValueError as err:
        raise RuntimeError("Conversion failed") from err
except RuntimeError as err:
    print("Chained:", err, "| caused by:", repr(err.__cause__))
