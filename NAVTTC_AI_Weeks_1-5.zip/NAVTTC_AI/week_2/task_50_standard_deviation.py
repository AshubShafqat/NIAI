"""Task 50 - Perform Standard Deviation"""
import numpy as np

# Standard deviation = how spread out the values are
speed1 = [86, 87, 88, 86, 87, 85, 86]
speed2 = [32, 111, 138, 28, 59, 77, 97]

std1 = np.std(speed1)
std2 = np.std(speed2)
print("Speeds 1:", speed1)
print("Mean = %.2f, Standard deviation = %.2f" % (np.mean(speed1), std1))   # 0.90
print("Speeds 2:", speed2)
print("Mean = %.2f, Standard deviation = %.2f" % (np.mean(speed2), std2))   # 37.85

# Variance = (standard deviation) ** 2
print("\nVariance 1:", np.var(speed1), "| check:", std1 ** 2)
print("Variance 2:", np.var(speed2), "| check:", std2 ** 2)

# Manual calculation step by step
data = speed2
mean = sum(data) / len(data)
variance = sum((x - mean) ** 2 for x in data) / len(data)
print("\nManual variance: %.2f, manual std: %.2f" % (variance, variance ** 0.5))

# Population (ddof=0, default) vs Sample (ddof=1) standard deviation
print("Population std: %.2f | Sample std: %.2f" % (np.std(speed2), np.std(speed2, ddof=1)))

# 68-95-99.7 rule: values within 1 standard deviation of the mean
within = [x for x in speed2 if abs(x - np.mean(speed2)) <= std2]
print("Values within 1 std of mean:", within)
