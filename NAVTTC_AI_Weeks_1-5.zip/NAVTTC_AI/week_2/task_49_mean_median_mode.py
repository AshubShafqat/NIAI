"""Task 49 - Perform Mean, Median and Mode"""
import statistics

import numpy as np

# Speed of 13 cars
speed = [99, 86, 87, 88, 111, 86, 103, 87, 94, 78, 77, 85, 86]

# Mean - the average value
mean_value = np.mean(speed)
print("Mean   :", mean_value)                 # 89.77

# Median - the middle value after sorting
median_value = np.median(speed)
print("Median :", median_value)               # 87.0

# Median with an even number of values (average of the two middle ones)
print("Median (even count) :", np.median([99, 86, 87, 88, 86, 103, 87, 94]))

# Mode - the most frequent value
mode_value = statistics.mode(speed)
print("Mode   :", mode_value)                 # 86

# Mode using SciPy (optional)
try:
    from scipy import stats
    print("Mode (SciPy):", stats.mode(speed, keepdims=False).mode)
except ImportError:
    print("SciPy not installed - skipped")

# Everything at once with the standard library
print("\nstatistics module -> mean: %.2f, median: %s, mode: %s" % (
    statistics.mean(speed), statistics.median(speed), statistics.mode(speed)))
