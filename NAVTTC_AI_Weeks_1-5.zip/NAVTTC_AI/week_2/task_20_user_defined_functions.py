"""Task 20 - Exercise on User defined functions in Python"""


# 1. Simple function
def greet():
    print("Hello from a function!")


greet()


# 2. Parameters and return value
def add(a, b):
    return a + b


print("add(3, 4) =", add(3, 4))


# 3. Default arguments
def power(base, exponent=2):
    return base ** exponent


print("power(5) =", power(5), "| power(2, 5) =", power(2, 5))


# 4. Keyword arguments
def intro(name, age, city="Faisalabad"):
    print(f"{name} is {age} years old and lives in {city}")


intro(age=21, name="Ali")


# 5. Variable length arguments (*args, **kwargs)
def total(*args):
    return sum(args)


def show_info(**kwargs):
    for k, v in kwargs.items():
        print(f"  {k}: {v}")


print("total(1,2,3,4) =", total(1, 2, 3, 4))
show_info(name="Sara", course="AI")


# 6. Returning multiple values
def min_max(numbers):
    return min(numbers), max(numbers)


low, high = min_max([4, 9, 1, 7])
print("min/max:", low, high)


# 7. Variable scope (local vs global)
x = "global"


def scope_demo():
    x = "local"
    print("inside function:", x)


scope_demo()
print("outside function:", x)


def change_global():
    global x
    x = "changed by function"


change_global()
print("after change_global():", x)


# 8. Recursion
def factorial(n):
    return 1 if n <= 1 else n * factorial(n - 1)


print("factorial(5) =", factorial(5))


# 9. Lambda, map, filter
square = lambda n: n ** 2
print("lambda square(6) =", square(6))
print("map   :", list(map(lambda n: n * 2, [1, 2, 3])))
print("filter:", list(filter(lambda n: n % 2 == 0, range(10))))


# 10. Inner (nested) function and docstring
def outer(msg):
    """Outer function that contains an inner function."""
    def inner():
        return msg.upper()
    return inner()


print(outer("nested function"))
print(outer.__doc__)


# 11. Function as an argument
def apply(func, value):
    return func(value)


print("apply(len, 'python') =", apply(len, "python"))
