"""Task 27 - Exercise on User defined Exception Handling in Python"""


# 1. Basic custom exception
class Error(Exception):
    """Base class for other exceptions"""
    pass


class ValueTooSmallError(Error):
    """Raised when the input value is too small"""
    pass


class ValueTooLargeError(Error):
    """Raised when the input value is too large"""
    pass


# Guess-the-number program (inputs simulated so the script runs on its own)
number = 10
for guess in [4, 15, 10]:
    try:
        if guess < number:
            raise ValueTooSmallError
        elif guess > number:
            raise ValueTooLargeError
        print(f"Guess {guess}: Congratulations! You guessed it.")
    except ValueTooSmallError:
        print(f"Guess {guess}: This value is too small, try again!")
    except ValueTooLargeError:
        print(f"Guess {guess}: This value is too large, try again!")


# 2. Custom exception with its own message and attributes
class SalaryNotInRangeError(Exception):
    def __init__(self, salary, message="Salary is not in (5000, 15000) range"):
        self.salary = salary
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f"{self.salary} -> {self.message}"


for salary in [7000, 20000]:
    try:
        if not 5000 < salary < 15000:
            raise SalaryNotInRangeError(salary)
        print(f"Salary {salary} accepted")
    except SalaryNotInRangeError as err:
        print("Caught:", err)


# 3. Custom exception in a bank account example
class InsufficientFundsError(Exception):
    def __init__(self, balance, amount):
        super().__init__(f"Cannot withdraw {amount}; balance is only {balance}")
        self.balance = balance
        self.amount = amount


class Account:
    def __init__(self, balance):
        self.balance = balance

    def withdraw(self, amount):
        if amount > self.balance:
            raise InsufficientFundsError(self.balance, amount)
        self.balance -= amount
        return self.balance


acc = Account(1000)
for amount in [400, 900]:
    try:
        print("New balance:", acc.withdraw(amount))
    except InsufficientFundsError as err:
        print("Error:", err, "| shortfall:", err.amount - err.balance)
    finally:
        print("Transaction attempt finished")
