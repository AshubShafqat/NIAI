"""
Task 1 - Installation
Download and install: Anaconda3, PyTorch, TensorFlow 2.0, VSCode, PyCharm

Installers cannot be "run" from a Python file, so this script
  1) prints the official download links / install commands, and
  2) CHECKS which of the required tools are already installed on this machine.
Run it before and after installing to verify everything is in place.
"""
import importlib
import shutil
import subprocess
import sys

INSTALL_GUIDE = """
=== HOW TO INSTALL ===
1. Anaconda3   : https://www.anaconda.com/download   (run the installer, tick "Add to PATH" if asked)
2. PyTorch     : conda install pytorch torchvision cpuonly -c pytorch
                 (or)  pip install torch torchvision
3. TensorFlow  : pip install tensorflow          (TensorFlow 2.x)
4. VSCode      : https://code.visualstudio.com/download
5. PyCharm     : https://www.jetbrains.com/pycharm/download  (Community edition is free)
"""


def check_python_package(import_name, label):
    try:
        module = importlib.import_module(import_name)
        version = getattr(module, "__version__", "unknown version")
        print(f"[ OK ] {label:<12} installed -> {version}")
        return True
    except Exception:
        print(f"[MISS] {label:<12} NOT installed")
        return False


def check_command(commands, label, version_flag="--version"):
    for cmd in commands:
        path = shutil.which(cmd)
        if path:
            try:
                out = subprocess.run([path, version_flag], capture_output=True,
                                     text=True, timeout=20)
                first = (out.stdout or out.stderr).strip().splitlines()
                info = first[0] if first else path
            except Exception:
                info = path
            print(f"[ OK ] {label:<12} found -> {info}")
            return True
    print(f"[MISS] {label:<12} NOT found on PATH")
    return False


def main():
    print(f"Python in use: {sys.version.split()[0]}  ({sys.executable})\n")
    print("=== INSTALLATION CHECK ===")
    check_command(["conda"], "Anaconda3")
    check_python_package("torch", "PyTorch")
    if check_python_package("tensorflow", "TensorFlow"):
        import tensorflow as tf
        if not tf.__version__.startswith(("2.",)):
            print("       Warning: TensorFlow 2.x is required.")
    check_command(["code"], "VSCode")
    check_command(["pycharm", "pycharm.sh", "pycharm-community", "charm"], "PyCharm")
    print(INSTALL_GUIDE)


if __name__ == "__main__":
    main()
