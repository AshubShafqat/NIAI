"""Task 21 - Exercise on List data type in Python"""

fruits = ["apple", "banana", "cherry"]
print("List:", fruits, "| length:", len(fruits))

# Indexing and slicing
print(fruits[0], fruits[-1], fruits[0:2], fruits[::-1])

# Adding items
fruits.append("orange")
fruits.insert(1, "kiwi")
fruits.extend(["mango", "grapes"])
print("After adding:", fruits)

# Changing items
fruits[0] = "green apple"
print("After changing:", fruits)

# Removing items
fruits.remove("kiwi")
popped = fruits.pop()
del fruits[0]
print("After removing:", fruits, "| popped:", popped)

# Useful methods
nums = [5, 2, 9, 1, 5, 6]
nums.sort()
print("Sorted:", nums)
nums.reverse()
print("Reversed:", nums)
print("count(5):", nums.count(5), "| index(9):", nums.index(9))
print("min/max/sum:", min(nums), max(nums), sum(nums))

# Copy and concatenation
copy = nums.copy()
print("Concatenate:", copy + [100, 200], "| repeat:", [0] * 3)

# Membership, loop and comprehension
print("9 in nums:", 9 in nums)
print("Squares:", [n ** 2 for n in nums])

# Nested list
matrix = [[1, 2, 3], [4, 5, 6]]
print("matrix[1][2] =", matrix[1][2])

nums.clear()
print("After clear:", nums)
