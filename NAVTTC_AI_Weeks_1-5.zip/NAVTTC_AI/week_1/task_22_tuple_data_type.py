"""Task 22 - Exercise on Tuple data type in Python"""

t = ("apple", "banana", "cherry", "apple")
print("Tuple:", t, "| length:", len(t))

# Indexing and slicing
print(t[0], t[-1], t[1:3])

# Single element tuple needs a comma
single = ("only",)
print(type(single), type(("only")))

# Tuples are immutable
try:
    t[0] = "mango"
except TypeError as err:
    print("Error:", err)

# Workaround: convert to list and back
temp = list(t)
temp[0] = "mango"
t = tuple(temp)
print("Modified copy:", t)

# Methods
print("count('apple'):", t.count("apple"), "| index('banana'):", t.index("banana"))

# Packing and unpacking
person = ("Ali", 21, "Faisalabad")
name, age, city = person
print(name, age, city)
first, *rest = (1, 2, 3, 4)
print(first, rest)

# Concatenation, repetition, membership
print((1, 2) + (3, 4), (0,) * 3, 2 in (1, 2, 3))

# Looping and nesting
for item in person:
    print(item, end=" ")
print()
nested = ((1, 2), (3, 4))
print("nested[1][0] =", nested[1][0])

# Tuple as dictionary key
locations = {(31.4, 73.1): "Faisalabad"}
print(locations[(31.4, 73.1)])
