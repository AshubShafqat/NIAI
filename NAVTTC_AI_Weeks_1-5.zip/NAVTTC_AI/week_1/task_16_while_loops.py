"""Task 16 - Exercise on While loops in Python"""

# 1. Basic while loop
count = 0
while count < 5:
    print("Count is", count)
    count += 1

# 2. Sum of first n natural numbers
n, i, total = 10, 1, 0
while i <= n:
    total += i
    i += 1
print("Sum of 1..10 =", total)

# 3. Countdown
x = 5
while x > 0:
    print(x, end=" ")
    x -= 1
print("Liftoff!")

# 4. while-else
y = 0
while y < 3:
    print("y =", y)
    y += 1
else:
    print("while condition became False, else block executed")

# 5. Factorial using while
num, fact = 5, 1
while num > 1:
    fact *= num
    num -= 1
print("5! =", fact)

# 6. Digit sum
number, digit_sum = 12345, 0
while number > 0:
    digit_sum += number % 10
    number //= 10
print("Digit sum of 12345 =", digit_sum)

# 7. Infinite loop with a break
k = 0
while True:
    k += 1
    if k == 3:
        print("Breaking infinite loop at", k)
        break

# 8. Fibonacci series
a, b = 0, 1
print("Fibonacci:", end=" ")
while a < 50:
    print(a, end=" ")
    a, b = b, a + b
print()
