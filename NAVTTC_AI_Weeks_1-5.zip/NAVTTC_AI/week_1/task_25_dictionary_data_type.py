"""Task 25 - Exercise on Dictionary data type in Python"""

student = {"name": "Ali", "age": 21, "city": "Faisalabad"}
print("Dictionary:", student, "| length:", len(student))

# Accessing
print(student["name"], student.get("age"), student.get("marks", "N/A"))

# Adding / updating
student["marks"] = 88
student["age"] = 22
student.update({"degree": "BSCS", "city": "Lahore"})
print("After changes:", student)

# Removing
removed = student.pop("degree")
last = student.popitem()
del student["city"]
print("After removing:", student, "| popped:", removed, last)

# Keys, values, items
d = {"a": 1, "b": 2, "c": 3}
print(list(d.keys()), list(d.values()), list(d.items()))

# Looping
for key, value in d.items():
    print(key, "=>", value)

# setdefault, fromkeys, copy
d.setdefault("d", 4)
print(d, dict.fromkeys(["x", "y"], 0), d.copy())

# Membership
print("a" in d, "z" in d)

# Dictionary comprehension
print({n: n ** 2 for n in range(1, 6)})

# Nested dictionary
students = {
    "s1": {"name": "Ali", "marks": 90},
    "s2": {"name": "Sara", "marks": 95},
}
print(students["s2"]["name"], students["s2"]["marks"])

# Sorting by value and merging
print(sorted(d.items(), key=lambda kv: kv[1], reverse=True))
print({**d, "e": 5})

d.clear()
print("After clear:", d)
