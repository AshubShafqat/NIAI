"""Task 15 - Exercise on for loops in Python"""

# 1. Looping over a list
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)

# 2. range()
print("\nrange(5):")
for i in range(5):
    print(i, end=" ")
print("\nrange(2, 10, 2):")
for i in range(2, 10, 2):
    print(i, end=" ")

# 3. Looping over a string
print("\n\nCharacters of 'Python':")
for ch in "Python":
    print(ch, end="-")

# 4. Looping over tuple, set and dictionary
print("\n\nTuple:")
for item in (1, 2, 3):
    print(item, end=" ")
print("\nDictionary items:")
d = {"name": "Ali", "age": 21}
for key, value in d.items():
    print(key, "->", value)

# 5. Index based looping
print("\nIndex based:")
for i in range(len(fruits)):
    print(i, fruits[i])

# 6. Nested for loops (pattern)
print("\nTriangle pattern:")
for i in range(1, 6):
    print("*" * i)

# 7. for-else
for n in range(3):
    print(n, end=" ")
else:
    print("\nLoop finished without break")

# 8. Sum and multiplication table
total = 0
for n in range(1, 11):
    total += n
print("\nSum of 1..10 =", total)
for i in range(1, 11):
    print(f"5 x {i} = {5 * i}")
