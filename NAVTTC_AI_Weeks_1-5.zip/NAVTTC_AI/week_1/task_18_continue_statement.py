"""Task 18 - Exercise on Continue statement in Python"""

# 1. Skip a letter
for letter in "geeksforgeeks":
    if letter == "e" or letter == "s":
        continue
    print(letter, end=" ")
print()

# 2. Skip the number 5
for i in range(1, 11):
    if i == 5:
        continue
    print(i, end=" ")
print()

# 3. continue in a while loop (print odd numbers)
n = 0
while n < 10:
    n += 1
    if n % 2 == 0:
        continue
    print(n, end=" ")
print()

# 4. Skip negative numbers while summing
values = [3, -1, 4, -5, 9]
total = 0
for v in values:
    if v < 0:
        continue
    total += v
print("Sum of positive numbers =", total)

# 5. Skip vowels in a string
text = "continue statement"
print("".join(ch for ch in text if ch not in "aeiou"))
result = ""
for ch in text:
    if ch in "aeiou":
        continue
    result += ch
print(result)
