"""Task 17 - Exercise on Break statement in Python"""

# 1. break in a for loop
for letter in "geeksforgeeks":
    if letter == "e" or letter == "s":
        print("Stopped at:", letter)
        break
    print(letter, end=" ")

# 2. break in a while loop
i = 0
while i < 10:
    if i == 5:
        print("\nbreak at i =", i)
        break
    print(i, end=" ")
    i += 1

# 3. Searching in a list
numbers = [4, 8, 15, 16, 23, 42]
target = 16
for idx, value in enumerate(numbers):
    if value == target:
        print(f"\nFound {target} at index {idx}")
        break
else:
    print("\nTarget not found")

# 4. break only exits the innermost loop
for a in range(3):
    for b in range(3):
        if b == 2:
            break
        print(f"a={a}, b={b}")

# 5. First prime greater than 20
for n in range(21, 100):
    for d in range(2, int(n ** 0.5) + 1):
        if n % d == 0:
            break
    else:
        print("First prime after 20 is", n)
        break
