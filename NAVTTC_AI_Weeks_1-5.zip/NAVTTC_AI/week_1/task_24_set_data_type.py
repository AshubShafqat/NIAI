"""Task 24 - Exercise on Set data type in Python"""

s = {1, 2, 3, 3, 2}
print("Set (duplicates removed):", s, "| length:", len(s))

# Creating
print(set([1, 2, 2, 3]), set("hello"), type(set()))

# Adding and removing
s.add(4)
s.update([5, 6])
print("After add/update:", s)
s.remove(6)
s.discard(100)          # no error if missing
popped = s.pop()
print("After removing:", s, "| popped:", popped)

# Set operations
a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print("Union          :", a | b, a.union(b))
print("Intersection   :", a & b, a.intersection(b))
print("Difference     :", a - b, a.difference(b))
print("Symmetric diff :", a ^ b, a.symmetric_difference(b))

# Subset / superset / disjoint
print({1, 2}.issubset(a), a.issuperset({1, 2}), a.isdisjoint({9, 10}))

# Membership and looping
print(3 in a)
for item in sorted(a):
    print(item, end=" ")
print()

# Remove duplicates from a list
duplicates = [1, 2, 2, 3, 3, 3]
print("Unique:", list(set(duplicates)))

# frozenset (immutable set)
fs = frozenset([1, 2, 3])
print(fs)

# Set comprehension
print({x ** 2 for x in range(5)})

s.clear()
print("After clear:", s)
