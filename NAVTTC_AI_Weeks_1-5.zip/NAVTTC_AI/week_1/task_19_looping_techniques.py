"""Task 19 - Exercise on various looping techniques in Python"""

# 1. enumerate()
for i, name in enumerate(["tic", "tac", "toe"], start=1):
    print(i, name)

# 2. zip() - loop over two or more sequences at once
questions = ["name", "quest", "favourite color"]
answers = ["lancelot", "the holy grail", "blue"]
for q, a in zip(questions, answers):
    print(f"What is your {q}? It is {a}.")

# 3. reversed()
print("\nReversed:")
for i in reversed(range(1, 6)):
    print(i, end=" ")

# 4. sorted()
print("\n\nSorted (unique):")
basket = ["apple", "orange", "apple", "pear", "orange", "banana"]
for f in sorted(set(basket)):
    print(f)

# 5. items() of a dictionary
print("\nDictionary:")
knights = {"gallahad": "the pure", "robin": "the brave"}
for k, v in knights.items():
    print(k, v)

# 6. List comprehension
print("\nSquares:", [x ** 2 for x in range(1, 6)])

# 7. Dictionary / set comprehension
print("Dict comp:", {x: x ** 3 for x in range(1, 4)})
print("Set comp :", {x % 3 for x in range(10)})

# 8. Iterator protocol: iter() and next()
it = iter([10, 20, 30])
print("\nIterator:", next(it), next(it), next(it))

# 9. itertools
import itertools
print("Product:", list(itertools.product("AB", [1, 2])))
print("Chain  :", list(itertools.chain([1, 2], [3, 4])))

# 10. Loop with step and nested loops
for i in range(0, 20, 5):
    print(i, end=" ")
print()
for i in range(1, 4):
    for j in range(1, 4):
        print(i * j, end="\t")
    print()
