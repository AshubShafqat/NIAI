"""Task 23 - Exercise on String data type in Python"""

s = "Hello, Python World"
print("String:", s, "| length:", len(s))

# Indexing and slicing
print(s[0], s[-1], s[0:5], s[7:], s[::-1])

# Case methods
print(s.upper(), s.lower(), s.title(), s.swapcase(), s.capitalize())

# Search and replace
print("find('Python'):", s.find("Python"), "| count('o'):", s.count("o"))
print(s.replace("World", "AI"))
print("startswith('Hello'):", s.startswith("Hello"), "| endswith('d'):", s.endswith("d"))

# Strip, split, join
padded = "   spaces around   "
print(f"[{padded.strip()}] [{padded.lstrip()}] [{padded.rstrip()}]")
words = s.split(", ")
print(words, "->", " | ".join(words))

# Checking methods
print("abc123".isalnum(), "abc".isalpha(), "123".isdigit(), "   ".isspace())

# Formatting
name, marks = "Ali", 92.456
print("Name: %s, Marks: %.1f" % (name, marks))
print("Name: {}, Marks: {:.2f}".format(name, marks))
print(f"Name: {name}, Marks: {marks:.0f}")

# Alignment
print("left".ljust(10, "-"), "right".rjust(10, "-"), "mid".center(10, "-"), "7".zfill(3))

# Concatenation, repetition, membership, escape characters
print("Py" + "thon", "ab" * 3, "Py" in "Python")
print("Tab\tseparated and a new\nline, quote: \"hi\"")
print(r"Raw string \n not escaped")

# Strings are immutable
try:
    s[0] = "J"
except TypeError as err:
    print("Error:", err)

# Palindrome check
word = "madam"
print(word, "is palindrome:", word == word[::-1])
