"""
Task 2 - Linux Commands
Practice: pwd, cd, ls, cat, sudo, man, redirection, mkdir, rm, rmdir, cp, mv,
file, reading, cat, more, less, head, alias, shutdown, restart, touch, nano,
bash, sh, chmod, ps, kill, dpkg

This script runs each command for real inside a throw-away practice folder
(a temporary directory) so nothing on your system is disturbed.
Dangerous commands (shutdown / restart) and interactive ones (nano, sudo
password prompts) are only demonstrated, never executed.
Works on Linux / Debian / Ubuntu / WSL / macOS.
"""
import os
import shutil
import subprocess
import tempfile
import time


def run(cmd, cwd=None):
    """Run a shell command through bash and print the command + its output."""
    print(f"\n$ {cmd}")
    try:
        result = subprocess.run(["bash", "-c", cmd], cwd=cwd, capture_output=True,
                                text=True, timeout=30)
        out = (result.stdout + result.stderr).rstrip()
        print(out if out else "(no output)")
    except FileNotFoundError:
        print("bash not found - run this on Linux/WSL/macOS.")
    except Exception as exc:
        print(f"(could not run: {exc})")


def main():
    base = tempfile.mkdtemp(prefix="linux_practice_")
    print("Practice directory:", base)

    print("\n##### Navigation #####")
    run("pwd", base)                                   # print working directory
    run("mkdir -p projects/demo docs", base)           # mkdir
    run("cd projects && pwd && cd .. && pwd", base)    # cd
    run("ls -la", base)                                # ls

    print("\n##### Files: touch, redirection, cat, cp, mv #####")
    run("touch notes.txt", base)                       # touch
    run("echo 'Hello Linux' > notes.txt", base)        # redirection (overwrite)
    run("echo 'Second line' >> notes.txt", base)       # redirection (append)
    run("for i in 1 2 3 4 5 6 7 8 9 10 11 12; do echo \"line $i\" >> long.txt; done", base)
    run("cat notes.txt", base)                         # cat
    run("cp notes.txt docs/notes_copy.txt", base)      # cp
    run("mv docs/notes_copy.txt docs/renamed.txt", base)  # mv
    run("ls docs", base)

    print("\n##### Reading files: file, more, less, head #####")
    run("file notes.txt", base)                        # file
    run("head -n 3 long.txt", base)                    # head
    run("more long.txt | head -n 5", base)             # more (pager)
    run("less -F long.txt | head -n 5", base)          # less (pager, quits on short files)

    print("\n##### alias #####")
    run("shopt -s expand_aliases; alias ll='ls -l'; alias ll", base)
    run("shopt -s expand_aliases; alias ll='ls -l'; ll", base)

    print("\n##### Help: man #####")
    run("man ls 2>/dev/null | head -n 5 || echo 'man pages not installed'", base)

    print("\n##### Scripts: bash, sh, chmod #####")
    with open(os.path.join(base, "hello.sh"), "w") as fh:
        fh.write("#!/bin/bash\necho 'Hello from a shell script'\n")
    run("chmod +x hello.sh && ls -l hello.sh", base)   # chmod
    run("./hello.sh", base)
    run("bash hello.sh", base)                         # bash
    run("sh hello.sh", base)                           # sh

    print("\n##### Environment variables #####")
    run("export MY_VAR='AI Course'; echo $MY_VAR; echo $HOME", base)

    print("\n##### Processes: ps, kill #####")
    sleeper = subprocess.Popen(["sleep", "60"])        # start a background process
    time.sleep(0.5)
    run(f"ps -p {sleeper.pid}", base)                  # ps
    run("ps aux | head -n 3", base)
    run(f"kill {sleeper.pid} && echo 'killed process {sleeper.pid}'", base)  # kill
    sleeper.wait()

    print("\n##### Packages: dpkg, apt (Debian/Ubuntu) #####")
    run("dpkg --version | head -n 1 || echo 'dpkg not available (not Debian/Ubuntu)'", base)
    run("dpkg -l 2>/dev/null | head -n 5", base)
    print("\n(Update/upgrade needs root, shown only)  $ sudo apt update && sudo apt upgrade -y")

    print("\n##### sudo / nano / shutdown / restart (demonstration only) #####")
    run("sudo -n true 2>/dev/null && echo 'sudo available without password' || echo 'sudo needs password / not available'", base)
    print("$ nano notes.txt         # opens the nano text editor (Ctrl+O save, Ctrl+X exit)")
    print("$ sudo shutdown now      # powers the machine off  (NOT executed)")
    print("$ sudo shutdown -r now   # restart the machine     (NOT executed)")
    print("$ sudo reboot            # restart the machine     (NOT executed)")

    print("\n##### Cleanup: rm, rmdir #####")
    run("rm notes.txt long.txt hello.sh", base)        # rm (files)
    run("rm docs/renamed.txt && rmdir docs", base)     # rmdir (empty dir)
    run("rm -r projects", base)                        # rm -r (non-empty dir)
    run("ls -la", base)

    shutil.rmtree(base, ignore_errors=True)
    print("\nDone. Practice folder removed.")


if __name__ == "__main__":
    main()
