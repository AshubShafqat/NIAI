# Taking kilometers input from the user
kilometers = float(input("Enter value in kilometers: "))

# conversion factor
conv_fac = 0.621371

# calculate miles
miles = kilometers * conv_fac

# (display line added so the result is visible when the program runs)
print('%0.3f kilometers is equal to %0.3f miles' %(kilometers,miles))
