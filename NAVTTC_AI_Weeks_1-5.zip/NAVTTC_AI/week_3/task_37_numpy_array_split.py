"""Task 37 - NumPy: splitting arrays"""
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6])
newarr = np.array_split(arr, 3)
print("array_split(3):", newarr)
print("first part:", newarr[0], "| second part:", newarr[1])

# Uneven split
print("array_split(4):", np.array_split(arr, 4))

# split() needs an equal division
print("split(3):", np.split(arr, 3))
try:
    np.split(arr, 4)
except ValueError as err:
    print("ValueError:", err)

# Splitting 2-D arrays
arr2d = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
print("\nRows split in 3:")
for part in np.array_split(arr2d, 3):
    print(part)
print("Split along axis=1:", np.array_split(arr2d, 2, axis=1))
print("hsplit:", np.hsplit(np.array([[1, 2, 3], [4, 5, 6]]), 3))
print("vsplit:", np.vsplit(arr2d, 2))
