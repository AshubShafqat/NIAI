"""Task 36 - NumPy: joining (concatenating) arrays"""
import numpy as np

# concatenate
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
print("concatenate:", np.concatenate((arr1, arr2)))

# 2-D, axis=1 (side by side) and axis=0 (stacked)
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [7, 8]])
print("axis=0:\n", np.concatenate((a, b), axis=0))
print("axis=1:\n", np.concatenate((a, b), axis=1))

# stack functions
print("stack (axis=1):\n", np.stack((arr1, arr2), axis=1))
print("hstack:", np.hstack((arr1, arr2)))
print("vstack:\n", np.vstack((arr1, arr2)))
print("dstack:\n", np.dstack((arr1, arr2)))

# append and insert
print("append:", np.append(arr1, [7, 8]))
print("insert:", np.insert(arr1, 1, 99))
