"""Task 31 - NumPy: data types"""
import numpy as np

# Data type of an array
print(np.array([1, 2, 3, 4]).dtype)               # int64
print(np.array(["apple", "banana", "cherry"]).dtype)   # <U6

# Creating arrays with a defined type
print(np.array([1, 2, 3, 4], dtype="S").dtype)    # bytes
print(np.array([1, 2, 3, 4], dtype="i4"), np.array([1, 2, 3, 4], dtype="i4").dtype)

# Converting data type of an existing array: astype()
arr = np.array([1.1, 2.1, 3.1])
print("float -> int :", arr.astype("i"), arr.astype(int).dtype)
arr = np.array([1, 0, 3])
print("int -> bool  :", arr.astype(bool))
print("int -> float :", np.array([1, 2, 3]).astype(float))

# A value that cannot be converted raises an error
try:
    np.array(["a", "2", "3"], dtype="i")
except ValueError as err:
    print("ValueError:", err)

# Common type codes: i int, u unsigned int, f float, c complex (c8 = complex64), ? bool, S bytes string, U unicode
for code in ["i", "u4", "f", "c8", "?", "S1", "U1"]:
    print(code, "->", np.dtype(code))
