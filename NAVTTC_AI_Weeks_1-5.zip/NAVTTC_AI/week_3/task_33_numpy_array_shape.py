"""Task 33 - NumPy: array shape"""
import numpy as np

arr = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
print("Shape of 2-D array:", arr.shape)        # (2, 4)

# Shape of an array with ndmin=5
arr5 = np.array([1, 2, 3, 4], ndmin=5)
print(arr5)
print("shape of 5-D array:", arr5.shape)       # (1, 1, 1, 1, 4)

# Other shape related attributes
arr3 = np.zeros((2, 3, 4))
print("ndim :", arr3.ndim)
print("size :", arr3.size)
print("shape:", arr3.shape)
print("dtype:", arr3.dtype)
print("itemsize (bytes per element):", arr3.itemsize)
print("nbytes:", arr3.nbytes)
