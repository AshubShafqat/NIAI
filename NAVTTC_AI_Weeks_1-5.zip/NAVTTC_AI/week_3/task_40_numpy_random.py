"""Task 40 - NumPy: random numbers"""
import numpy as np
from numpy import random

# Reproducible results
rng = np.random.default_rng(seed=42)

# Random integer / float
print("randint(100)      :", random.randint(100))
print("rand()            :", random.rand())
print("randint array     :", random.randint(100, size=5))
print("randint 2-D       :\n", random.randint(100, size=(3, 5)))
print("rand array        :", random.rand(5))
print("rand 2-D          :\n", random.rand(3, 5))

# Random choice from an array
print("choice            :", random.choice([3, 5, 7, 9]))
print("choice 2-D        :\n", random.choice([3, 5, 7, 9], size=(3, 5)))

# Data distribution: choice with probabilities
print("distribution      :", random.choice([3, 5, 7, 9], p=[0.1, 0.3, 0.6, 0.0], size=10))

# Random permutations
arr = np.array([1, 2, 3, 4, 5])
print("shuffle (in-place):", (random.shuffle(arr), arr)[1])
print("permutation       :", random.permutation(np.array([1, 2, 3, 4, 5])))

# Normal distribution, seeded generator
print("normal (seeded)   :", rng.normal(loc=0, scale=1, size=5).round(3))
print("uniform (seeded)  :", rng.uniform(0, 1, size=3).round(3))
