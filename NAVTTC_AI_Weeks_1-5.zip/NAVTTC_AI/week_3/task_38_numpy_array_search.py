"""Task 38 - NumPy: searching arrays"""
import numpy as np

# where(): indexes where a condition is true
arr = np.array([1, 2, 3, 4, 5, 4, 4])
print("Index where value is 4  :", np.where(arr == 4))
print("Index of even values    :", np.where(arr % 2 == 0))

# searchsorted(): binary search in a SORTED array
arr = np.array([6, 7, 8, 9])
print("searchsorted(7)               :", np.searchsorted(arr, 7))
print("searchsorted(7, side='right') :", np.searchsorted(arr, 7, side="right"))
print("searchsorted([2, 4, 6, 8])    :", np.searchsorted(arr, [2, 4, 6, 8]))
print("searchsorted(10)              :", np.searchsorted(arr, 10))

# Other search helpers
data = np.array([3, 9, 1, 7])
print("argmax:", data.argmax(), "| argmin:", data.argmin())
print("any > 8:", (data > 8).any(), "| all > 0:", (data > 0).all())
print("nonzero:", np.nonzero(np.array([0, 3, 0, 5])))
print("Condition-based replace:", np.where(data > 5, "big", "small"))
