"""Task 32 - NumPy: array copy vs view"""
import numpy as np

# COPY: a new array, changes do NOT affect the original
arr = np.array([1, 2, 3, 4, 5])
x = arr.copy()
arr[0] = 42
print("original:", arr)
print("copy    :", x)

# VIEW: shares data, changes DO affect the original
arr = np.array([1, 2, 3, 4, 5])
y = arr.view()
arr[0] = 42
print("\noriginal:", arr)
print("view    :", y)

arr = np.array([1, 2, 3, 4, 5])
y = arr.view()
y[0] = 31
print("change made in view -> original:", arr, "| view:", y)

# Ownership: base attribute
arr = np.array([1, 2, 3, 4, 5])
x = arr.copy()
y = arr.view()
print("\ncopy.base:", x.base)       # None -> owns its data
print("view.base:", y.base)         # original array

# Slices are views, fancy indexing returns copies
a = np.arange(6)
s = a[1:4]
s[0] = 99
print("\nslice modified the original ->", a)
f = a[[1, 2]]
f[0] = -1
print("fancy copy did not change the original ->", a)
