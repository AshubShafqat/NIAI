"""Task 29 - NumPy: array indexing"""
import numpy as np

arr = np.array([1, 2, 3, 4])
print("arr[0] =", arr[0])
print("arr[1] =", arr[1])
print("arr[2] + arr[3] =", arr[2] + arr[3])

# 2-D indexing (row, column)
arr2d = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
print("2nd element on 1st row:", arr2d[0, 1])
print("5th element on 2nd row:", arr2d[1, 4])

# 3-D indexing
arr3d = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
print("arr3d[0, 1, 2] =", arr3d[0, 1, 2])

# Negative indexing
print("Last element of 2nd row:", arr2d[1, -1])

# Boolean (logical) selection
print("Elements > 2:", arr[arr > 2])
print("Even elements:", arr[arr % 2 == 0])

# Fancy indexing
print("arr[[0, 2]] =", arr[[0, 2]])
