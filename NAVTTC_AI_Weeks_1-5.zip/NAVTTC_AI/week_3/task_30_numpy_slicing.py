"""Task 30 - NumPy: array slicing"""
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print("arr[1:5]  =", arr[1:5])
print("arr[4:]   =", arr[4:])
print("arr[:4]   =", arr[:4])
print("arr[-3:-1]=", arr[-3:-1])
print("arr[1:5:2]=", arr[1:5:2])
print("arr[::2]  =", arr[::2])
print("reversed  =", arr[::-1])

# 2-D slicing
arr2d = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
print("\n2nd row, index 1 to 4:", arr2d[1, 1:4])
print("Index 2 from both rows:", arr2d[0:2, 2])
print("Index 1 to 4 from both rows:\n", arr2d[0:2, 1:4])
print("First column:", arr2d[:, 0])
