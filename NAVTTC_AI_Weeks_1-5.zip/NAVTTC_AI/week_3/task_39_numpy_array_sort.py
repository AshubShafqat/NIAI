"""Task 39 - NumPy: sorting arrays"""
import numpy as np

print("Numbers :", np.sort(np.array([3, 2, 0, 1])))
print("Strings :", np.sort(np.array(["banana", "cherry", "apple"])))
print("Booleans:", np.sort(np.array([True, False, True])))

# 2-D arrays are sorted row by row
arr = np.array([[3, 2, 4], [5, 0, 1]])
print("2-D sort (last axis):\n", np.sort(arr))
print("2-D sort (axis=0):\n", np.sort(arr, axis=0))

# Descending order
print("Descending:", np.sort(np.array([3, 2, 0, 1]))[::-1])

# The original is unchanged; sort() returns a copy
original = np.array([5, 1, 4])
sorted_copy = np.sort(original)
print("original:", original, "| sorted copy:", sorted_copy)
original.sort()                      # in-place sort
print("after in-place sort:", original)

# argsort(): indexes that would sort the array
x = np.array([30, 10, 20])
print("argsort:", np.argsort(x), "->", x[np.argsort(x)])
