"""Task 28 - NumPy: creating arrays"""
import numpy as np

# 0-D, 1-D, 2-D and 3-D arrays
arr0 = np.array(42)
arr1 = np.array([1, 2, 3, 4, 5])
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
arr3 = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])

for name, a in [("0-D", arr0), ("1-D", arr1), ("2-D", arr2), ("3-D", arr3)]:
    print(f"{name} array:\n{a}\n  ndim = {a.ndim}")

print("\nNumPy version:", np.__version__)
print("Type:", type(arr1))

# From tuple and from list
print(np.array((1, 2, 3)))

# Higher dimensional array
print("5-D ndim:", np.array([1, 2, 3, 4], ndmin=5).ndim)

# Built-in creation methods
print("zeros :", np.zeros(4))
print("ones  :", np.ones((2, 3)))
print("arange:", np.arange(0, 10, 2))
print("linspace:", np.linspace(0, 1, 5))
print("eye   :\n", np.eye(3))
print("full  :", np.full((2, 2), 7))
