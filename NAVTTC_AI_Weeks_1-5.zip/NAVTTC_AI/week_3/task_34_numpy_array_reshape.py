"""Task 34 - NumPy: array reshaping"""
import numpy as np

# 1-D -> 2-D
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
print("(4, 3):\n", arr.reshape(4, 3))

# 1-D -> 3-D
print("(2, 3, 2):\n", arr.reshape(2, 3, 2))

# The number of elements must match
try:
    arr.reshape(3, 3)
except ValueError as err:
    print("ValueError:", err)

# Returns a view?
print("Base is original array:", arr.reshape(2, 6).base is arr)

# Unknown dimension: use -1
print("(2, 2, -1):\n", arr.reshape(2, 2, -1))

# Flattening
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
print("reshape(-1):", arr2.reshape(-1))
print("flatten()  :", arr2.flatten())
print("ravel()    :", arr2.ravel())

# Transpose and adding a dimension
print("Transpose:\n", arr2.T)
print("newaxis shape:", arr2[:, np.newaxis, :].shape)
