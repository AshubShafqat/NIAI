"""Task 35 - NumPy: array iteration"""
import numpy as np

# 1-D
arr = np.array([1, 2, 3])
for x in arr:
    print(x)

# 2-D (iterating gives rows)
arr = np.array([[1, 2, 3], [4, 5, 6]])
print("Rows:")
for x in arr:
    print(x)
print("Every element:")
for row in arr:
    for x in row:
        print(x, end=" ")
print()

# 3-D
arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
for x in arr:
    for y in x:
        for z in y:
            print(z, end=" ")
print()

# nditer(): iterate every element, whatever the dimensions
for x in np.nditer(arr):
    print(x, end=" ")
print()

# nditer with a different data type
for x in np.nditer(np.array([1, 2, 3]), flags=["buffered"], op_dtypes=["S"]):
    print(x, end=" ")
print()

# nditer with step
for x in np.nditer(arr[:, ::2, ::2]):
    print(x, end=" ")
print()

# ndenumerate(): iterate with index
for idx, x in np.ndenumerate(np.array([1, 2, 3])):
    print(idx, x)
for idx, x in np.ndenumerate(np.array([[1, 2, 3, 4], [5, 6, 7, 8]])):
    print(idx, x)
