# NAVTTC - AI / Machine Learning / Deep Learning : Weeks 1-5 Solutions

Every task is a standalone, runnable `.py` file (no notebooks). Run any file with:
    python task_XX_name.py

| Folder  | Tasks (Annexure-I)                                   | Topic |
|---------|------------------------------------------------------|-------|
| week_1  | 1-19, 21-25                                          | Installation, Linux commands, Python basics, conditionals, loops, data types |
| week_2  | 20, 26, 27, 49, 50                                   | Functions, exception handling, mean/median/mode, standard deviation |
| week_3  | 28-40                                                | NumPy |
| week_4  | 41-48                                                | Pandas |
| week_5  | 51, 52                                               | Linear & logistic regression |

Notes
- Tasks 3-14: the code from the task sheet is kept exactly as given (Task 10 only gets one added print line so its result is visible).
- Task 1 (installation) and Task 2 (Linux) cannot be "solved" in pure Python, so they are an installation checker and a safe command-practice script that runs inside a temporary folder.
- Tasks 28-48 are listed for "Week 3,4" in the sheet; NumPy (28-40) is placed in week_3 and Pandas (41-48) in week_4 to follow the schedule.
- Requirements: pip install numpy pandas scikit-learn matplotlib seaborn scipy
- Tasks 45, 48, 51, 52 save small CSV/PNG output files next to the script.
